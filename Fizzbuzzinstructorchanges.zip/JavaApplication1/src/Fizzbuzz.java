// @author liamk

public class Fizzbuzz  {
    
    public static void main(String[] args) {
        int i = 1;
        while(i <= 20) {
            if (i % 3 == 0 && i % 5 == 0) {   // check if div by 3 and 5
              System.out.println("Fizz Buzz");
            } else if (i % 3 == 0) {            // check if div by 3 only
                System.out.println("Fizz");
            } else if (i % 5 == 0) {
              System.out.println("Buzz");       // check if div by 5 only
            } else {                            // just print number
                System.out.println(i);
            } 
             
//            String prINT = i % 3 == 0 ? "Fizz" : Integer.toString(i);
//            prINT = i % 5 == 0 ? "Buzz" : prINT;
//            prINT = i % 3 == 0 && i % 5 == 0 ? "FizzBuzz" : prINT;
//            System.out.println(prINT);
            i++;
        }   
    }
}
